
  # Sistem Kelola Barang

  This is a code bundle for Sistem Kelola Barang. The original project is available at https://www.figma.com/design/ZCdmJjER1YRC4olMXkEAyn/Sistem-Kelola-Barang.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  